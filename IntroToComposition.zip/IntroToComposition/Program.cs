﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToComposition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var dbm = new DbMigrator(new Logger());

            var logger = new Logger();
            var inStaller = new Installer(logger);

            dbm.Migrate();
            inStaller.Install();
        }
    }
}
