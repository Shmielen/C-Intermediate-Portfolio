﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfacesAndPolymorphism
{
    public class MailNotificationChannel : INotificationChannel
    {
        public void send(Message message)
        {
            Console.WriteLine("Sending Mail");
        }

        
    }
}
