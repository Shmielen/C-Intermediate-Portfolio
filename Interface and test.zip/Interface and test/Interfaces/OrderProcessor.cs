﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interfaces
{
    public class OrderProcessor
    {
        private readonly IShippingCalculator _shippingCalculator;  //this was originally a field but due to tight coupling 
                                                                   //it was changed to an Interface
        public OrderProcessor(IShippingCalculator shippingCalculator)
        {
            _shippingCalculator = shippingCalculator;
        }

        public void Process(Order order) //unit test is necessary for this unit
        {
            if (order.IsShipped)  //first path
            {
                throw new InvalidOperationException("This order is already processed");
            }

            order.Shipment = new Shipment //second path
            {
                Cost = _shippingCalculator.CalculateShipping(order),
                ShippingDate = DateTime.Today.AddDays(1)
            };
        }
    }
}


