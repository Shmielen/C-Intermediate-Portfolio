﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismEX1
{
    class OracleConnection : DbConnection
    {
        public OracleConnection(string conString) : base(conString)
        {
        }

        public override void Close()
        {
            Console.WriteLine("Closing Oracle DB");
        }

        public override void Open()
        {
            Console.WriteLine("Opening Oracle DB"); ;
        }
    }
}
