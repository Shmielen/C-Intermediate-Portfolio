﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismEX1
{
    public class Program
    {
        static void Main(string[] args)
        {
            var sqldb = new SqlConnection("yeahyeah yeah");
            sqldb.Open();
            sqldb.Close();

            var orac = new OracleConnection("nah nah nah");
            orac.Open();
            orac.Close();

        }
    }
}
