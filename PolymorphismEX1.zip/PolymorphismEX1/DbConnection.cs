﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismEX1
{
    public abstract class DbConnection
    {
        public string _conString { get; set; }
        public TimeSpan Timeout { get; set; }

        public DbConnection(string conString)
        {
            if (!string.IsNullOrEmpty(conString))
                _conString = conString;
            else
                throw new Exception("Connection String is Missing");
        }

        public abstract void Open();


        public abstract void Close();
        
    }
}
