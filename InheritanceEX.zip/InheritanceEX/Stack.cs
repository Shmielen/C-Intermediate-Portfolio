﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceEX
{
    public class Stack
    {
        private List<object> list = new List<object>();

        public void Push(object obj)
        {
            list.Add(obj);
        }

        public object Pop()
        {
            object popped = list[list.Count - 1];
            list.RemoveAt(list.Count - 1);
            return popped;
        }

        public void Clear() 
        { 
            list.Clear();
        }

    }
}
