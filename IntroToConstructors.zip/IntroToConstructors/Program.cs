﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToConstructors
{
    class Program
    {
        static void Main(string[] args)
        {
            var cust = new Customer();
            cust.Id= 1;
            cust.Name = "John";

            var order = new Order();
            cust.Orders.Add(order);


            Console.WriteLine(cust.Name);
            Console.WriteLine(cust.Id);
        }
    }
}
