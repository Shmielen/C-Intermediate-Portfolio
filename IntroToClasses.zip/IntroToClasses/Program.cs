﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToClasses
{
    public class Person                //this program shows the creation of a custom class and how
                                       //it can be used within the main method
    {
        public string Name;

        public void Introduce( string to)
        {
            Console.WriteLine("Hi {0}, I am {1}", to, Name);
        }

        public static Person Parse(string str) 
        {
            var person = new Person();
            person.Name = str;

            return person;
        }
    }
    
    
    class Program
    {
        static void Main(string[] args)
        {
            var p = Person.Parse("John");
            p.Introduce("Nielen");
        }
    }
}
