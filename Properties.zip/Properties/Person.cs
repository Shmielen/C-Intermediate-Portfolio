﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Properties
{
    public class Person
    {
        public String Name { get; set; }

        public DateTime BirthDate { get; private set; } //private accessor allos for set to happen only on construction
        
        public Person(DateTime birthDate) //constructor
        {
            BirthDate = birthDate;
        }

        

        public int Age
        {
            get
            {
                var ts = DateTime.Today - BirthDate;
                var years = ts.Days / 365;

                return years;
            }
        }
    }
}
