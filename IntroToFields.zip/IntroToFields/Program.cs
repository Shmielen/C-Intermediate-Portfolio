﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToFields
{
    public class Program
    {
        static void Main(string[] args)
        {
            var cust = new Customer(1);
            cust.Orders.Add(new Order());
            cust.Orders.Add(new Order());

            Console.WriteLine(cust.Orders.Count);
        }
    }
}
