﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClassesEX1
{
    public class StopWatch
    {
        private DateTime start = new DateTime();
        private DateTime stop = new DateTime();
        private bool started = false;

        public void Start()
        {
            if(!started) 
            { 
                start = DateTime.Now;
                started = true;
            }
            else
            {
                throw new InvalidOperationException("Stopwatch has already started");
            }
            
        }

        public TimeSpan Stop()
        {
            stop = DateTime.Now;
            started= false;

            return stop - start;
        }
    }
}
