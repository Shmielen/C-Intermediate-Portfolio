﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var cook = new HttpCookie();
            cook["name"] = "Nielen";

            Console.WriteLine(cook["name"]);
        }
    }
}
