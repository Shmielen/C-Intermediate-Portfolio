﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesEX2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var post = new Post("Mr peanut in the house", "Its my party!!");
            Console.WriteLine(post._title); Console.WriteLine(post._description);
            post.UpVote();
            post.UpVote();
            post.DownVote();
            Console.WriteLine(post._votes);
            Console.WriteLine(post._timeCreated);
        }
    }
}
