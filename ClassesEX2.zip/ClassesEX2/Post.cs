﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesEX2
{
    public class Post
    {
        public int _votes { get; private set; }
        public string _title { get; set; }
        public string _description { get; set; }

        public DateTime _timeCreated { get; private set; }

        public Post(string title) 
        {
            this._votes = 0;
            this._title = title;
            this._timeCreated = DateTime.Now;
        }

        public Post(string title, string description)
            : this(title)
        {
            this._description = description;
        }

        public void UpVote()
        {
            this._votes++;
        }

        public void DownVote()
        {
            this._votes--;
        }
    }
}
