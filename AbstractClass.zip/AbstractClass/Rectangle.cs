﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    public class Rectangle : Shape
    {
        public override void Draw()  //just like with the virtual modifier, we use the override modifier when using abstract method
        {
            Console.WriteLine("Draw rectangle");
        }
    }
}
