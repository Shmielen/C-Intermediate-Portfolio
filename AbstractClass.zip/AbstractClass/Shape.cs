﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    public abstract class Shape //class declared as abstract
    {
        public int width;
        public int height;

        public abstract void Draw(); //any method without implementation is declared abstract rather than virtual

        public void Copy()
        {
            Console.WriteLine("Copy shape into clipboard");
        }

        public void Select()
        {
            Console.WriteLine("Select shape");
        }

    }
}
