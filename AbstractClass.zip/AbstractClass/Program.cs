﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            //var shape = new Shape();  //shape was declared abstract so it cannot be instantiated 
            
            var circ = new Circle();
            circ.Draw();

            var rec = new Rectangle();
            rec.Draw();

        }
    }
}
