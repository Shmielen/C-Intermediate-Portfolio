﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensibility
{
    class Program
    {
        static void Main(string[] args)
        {
            var condbm = new DbMigrator(new ConsoleLogger());
            condbm.Migrate();

            var fildbm = new DbMigrator(new FileLogger("C:\\Users\\Nielen\\C#proj\\Intermediate\\Extensibility\\log.txt"));
            fildbm.Migrate();
        }
    }
}
