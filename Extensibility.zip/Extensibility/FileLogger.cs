﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensibility
{
    public class FileLogger : ILogger
    {
        private readonly string _path;

        public FileLogger(string path)
        {
            _path = path;
        }
        
        public void LogError(string message)
        {
            //var sw = new StreamWriter(_path, true);
            //sw.WriteLine(message);
            Log(message, "ERROR");
           
        }

        public void LogInfo(string message)
        {
            Log(message, "INFO");
        }

        private void Log(string message, string messageType)
        {
            using (var sw = new StreamWriter(_path, true))
            {
                sw.WriteLine(messageType + ": " + message);
            }
        }
    }
}
