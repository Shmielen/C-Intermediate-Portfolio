﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extensibility
{
    public class DbMigrator
    {
        private readonly ILogger _logger;
        public DbMigrator(ILogger logger)
        {
            _logger = logger;
        }
        
        public void Migrate()
        {
            _logger.LogInfo("Migration started at" + DateTime.Now);
            //Console.WriteLine("Migration started at {0}", DateTime.Now);

            //migrate db
            _logger.LogInfo($"Migration ended at {DateTime.Now}");
            //Console.WriteLine("Migration ended at {0}", DateTime.Now);
        }
    }
}
