﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccessModifier
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var p = new Person();
            p.SetBirthDate(new DateTime(1982,1,1));
            Console.WriteLine(p.GetBirthDate());

        }
    }
}
