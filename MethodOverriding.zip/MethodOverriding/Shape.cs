﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    public class Shape
    {
        public int Height {get; set;}
        public int Width { get; set;}
        public Position position { get; set;}
        //public ShapeType Type { get; set;}      there is no longer need for this enum class becuase each shape will now get its own class
    
        public virtual void Draw()   //vitural keyword allows for method overide
        {

        }
    }
}

