﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    public class Circle : Shape
    {
        public override void Draw()  // override keyword allows for method from parent class to be used
        {
            // All circle specific draw code will be placed here
            Console.WriteLine("Draw circle");
            
            //base.Draw(); //inherits all the doce from the parent class draw method
        }
    }
}
