﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    public class Canvas
    {
        public void DrawShapes(List<Shape> shapes)
        {
            foreach (var shape in shapes)
            {
                //switch (shape.Type)     
                //{
                //    case ShapeType.Circle:
                //        Console.WriteLine("Draw a circle"); //this logic only happens for a circle so a circle class will be created
                //        break;

                //    case ShapeType.Triangle:
                //        Console.WriteLine("Draw a triangle");
                //        break;
                //}

                shape.Draw(); // overriding removes the need for a switch statement, the overridden method has code specific to each class
                              //only the releveant code will be run
                   
            }
        }
    }
}