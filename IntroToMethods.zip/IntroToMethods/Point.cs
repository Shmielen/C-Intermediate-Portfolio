﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToMethods
{
    class Point //point on screen
    {
        public int x;
        public int y;  //coords of point

        public Point(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public void Move(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public void Move(Point newLocation)//overload for the move method 
        {
            if (newLocation == null)//validates input 
            {
                throw new ArgumentNullException("newLocation");
            }
            Move(newLocation.x, newLocation.y);//this overload calls the original method 
        }
    }
}
