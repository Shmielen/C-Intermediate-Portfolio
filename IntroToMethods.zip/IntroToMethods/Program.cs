﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntroToMethods
{
    internal class Program
    {  
        static void Main(string[] args)
        {
            //var number = int.Parse("abc");   //will cuase program to crash

            int number;
            var result = int.TryParse("abc", out number);  //returns a bool showing if the3 conversion took place
            if(result)
            {
                Console.WriteLine(number);
            }
            else
            {
                Console.WriteLine("Conversion failed");
            }

        }

        static void UseParams()
        {
            var calc = new Calculator();
            Console.WriteLine(calc.Add(1, 2));
            Console.WriteLine(calc.Add(1, 2, 3, 4));
            Console.WriteLine(calc.Add(new int[] { 1, 2, 3, 4 }));
        }


        static void UsePoints()
        {
            try
            {
                var point = new Point(10, 20);
                point.Move(new Point(40, 60));
                Console.WriteLine("Point is at: ({0}  {1})", point.x.ToString(), point.y.ToString());

                point.Move(100, 200);
                Console.WriteLine("Point is at: ({0}  {1})", point.x.ToString(), point.y.ToString());
            }
            catch (Exception)
            {

                Console.WriteLine("Unexpected error occured");
            }
        }
    }
}
