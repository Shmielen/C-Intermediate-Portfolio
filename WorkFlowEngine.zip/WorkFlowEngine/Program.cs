﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WorkFlowEngine;

namespace WorkFlowEngineEX
{
    class Program
    {
        static void Main(string[] args)
        {
            var wf = new Workflow();
            wf.Add(new CallWebService());
            wf.Add(new ChangeStatus());
            wf.Add(new SendEmail());
            wf.Add(new UploadVideo());

            var engine = new WorkflowEngine();
            engine.Run(wf);
        }
    }
}
