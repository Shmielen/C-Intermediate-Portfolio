﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkFlowEngine
{
    public interface IWorkflow
    {
        void Add(IAction action);
        void Remove(IAction action);
        IEnumerable<IAction> GetActions();
    }
}
