﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkFlowEngine
{
    public class Workflow : IWorkflow
    {
        private readonly List<IAction> _actions;

        public Workflow()
        {
            _actions = new List<IAction>();
        }

        public void Add(IAction action)
        {
            _actions.Add(action);
        }

        public void Remove(IAction action)
        {
            _actions.Remove(action);
        }

        public IEnumerable<IAction> GetActions()
        {
            return _actions;
        }
    }
}
