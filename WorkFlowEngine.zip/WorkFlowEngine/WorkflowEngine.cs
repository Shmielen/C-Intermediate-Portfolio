﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkFlowEngine
{
    public class WorkflowEngine
    {
        public void Run(IWorkflow workflow)
        {
            foreach(IAction act in workflow.GetActions())
            {
                try
                {
                    act.Execute();
                }
                catch (Exception) { throw; }
            }
        }
    }
}
