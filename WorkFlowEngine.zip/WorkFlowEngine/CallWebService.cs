﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkFlowEngine
{
    public class CallWebService : IAction
    {
        public void Execute()
        {
            Console.WriteLine("Calling Web Servgice...");
        }
    }
}
